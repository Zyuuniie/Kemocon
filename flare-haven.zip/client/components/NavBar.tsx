import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function NavBar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-2 font-bold text-xl text-primary hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center text-white font-bold text-lg">
              🐾
            </div>
            <span className="hidden sm:inline">KemoCult!</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Home
            </Link>
            <Link
              to="/forum"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Showcase
            </Link>
            <Link
              to="/forum"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Community
            </Link>
          </div>

          {/* Auth Buttons - Desktop */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/login"
              className="px-4 py-2 rounded-lg font-semibold text-primary hover:bg-secondary transition-colors"
            >
              Log In
            </Link>
            <Link
              to="/register"
              className="px-4 py-2 rounded-lg font-semibold text-white bg-primary hover:bg-primary/90 transition-colors"
            >
              Join Us
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg hover:bg-secondary transition-colors"
            >
              {isOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-4 border-t border-border animate-slideUp">
            <div className="flex flex-col gap-4 pt-4">
              <Link
                to="/"
                className="text-foreground hover:text-primary transition-colors font-medium px-2"
              >
                Home
              </Link>
              <Link
                to="/forum"
                className="text-foreground hover:text-primary transition-colors font-medium px-2"
              >
                Showcase
              </Link>
              <Link
                to="/forum"
                className="text-foreground hover:text-primary transition-colors font-medium px-2"
              >
                Community
              </Link>
              <div className="flex gap-2 pt-2">
                <Link
                  to="/login"
                  className="flex-1 px-4 py-2 rounded-lg font-semibold text-primary text-center hover:bg-secondary transition-colors"
                >
                  Log In
                </Link>
                <Link
                  to="/register"
                  className="flex-1 px-4 py-2 rounded-lg font-semibold text-white bg-primary text-center hover:bg-primary/90 transition-colors"
                >
                  Join Us
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
