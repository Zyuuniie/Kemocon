import { useState } from "react";
import { Heart, MessageCircle, Share2, Upload, X } from "lucide-react";

interface Post {
  id: number;
  author: string;
  avatar: string;
  timestamp: string;
  title: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  liked: boolean;
}

export default function Forum() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [posts, setPosts] = useState<Post[]>([]);

  const [formData, setFormData] = useState({
    title: "",
    content: "",
  });

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.title.trim() || formData.content.trim()) {
      const newPost: Post = {
        id: posts.length + 1,
        author: "You",
        avatar: "YO",
        timestamp: "just now",
        title: formData.title,
        content: formData.content,
        likes: 0,
        comments: 0,
        liked: false,
      };
      setPosts([newPost, ...posts]);
      setFormData({ title: "", content: "" });
      setShowCreateModal(false);
    }
  };

  const toggleLike = (id: number) => {
    setPosts(
      posts.map((post) =>
        post.id === id
          ? {
              ...post,
              liked: !post.liked,
              likes: post.liked ? post.likes - 1 : post.likes + 1,
            }
          : post,
      ),
    );
  };

  return (
    <div className="w-full min-h-screen">
      {/* Forum Header */}
      <div className="bg-gradient-to-r from-primary/90 to-accent/90 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl sm:text-4xl font-bold mb-4">Showcase</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Posts Feed - Left/Center */}
          <div className="lg:col-span-2 space-y-6">
            {/* Create Post Button */}
            <button
              onClick={() => setShowCreateModal(true)}
              className="w-full card-post hover:shadow-lg transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white font-bold flex-shrink-0 text-lg">
                  🐾
                </div>
                <input
                  type="text"
                  placeholder="Share something..."
                  className="flex-1 bg-secondary rounded-lg px-4 py-3 text-muted-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 cursor-pointer"
                  onClick={() => setShowCreateModal(true)}
                  readOnly
                />
                <Upload className="w-5 h-5 text-muted-foreground" />
              </div>
            </button>

            {/* Posts List */}
            <div className="space-y-4">
              {posts.length === 0 ? (
                <div className="card-post text-center py-12">
                  <p className="text-muted-foreground"></p>
                </div>
              ) : (
                posts.map((post) => (
                  <div key={post.id} className="card-post animate-slideUp">
                    {/* Post Header */}
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {post.avatar}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-foreground">
                          {post.author}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {post.timestamp}
                        </p>
                      </div>
                    </div>

                    {/* Post Content */}
                    {post.title && (
                      <h3 className="text-lg font-semibold text-foreground mb-2">
                        {post.title}
                      </h3>
                    )}
                    <p className="text-foreground mb-4">{post.content}</p>

                    {/* Post Image */}
                    {post.image && (
                      <img
                        src={post.image}
                        alt={post.title}
                        className="w-full h-64 sm:h-80 object-cover rounded-lg mb-4"
                      />
                    )}

                    {/* Post Actions */}
                    <div className="flex items-center gap-4 pt-4 border-t border-border text-muted-foreground">
                      <button
                        onClick={() => toggleLike(post.id)}
                        className="flex items-center gap-2 hover:text-primary transition-colors group"
                      >
                        <div className="p-2 rounded-lg group-hover:bg-primary/10 transition-colors">
                          <Heart
                            className={`w-5 h-5 ${
                              post.liked
                                ? "fill-current text-primary"
                                : "hover:text-primary"
                            }`}
                          />
                        </div>
                        <span className="text-sm">{post.likes}</span>
                      </button>
                      <button className="flex items-center gap-2 hover:text-primary transition-colors group">
                        <div className="p-2 rounded-lg group-hover:bg-primary/10 transition-colors">
                          <MessageCircle className="w-5 h-5" />
                        </div>
                        <span className="text-sm">{post.comments}</span>
                      </button>
                      <button className="flex items-center gap-2 hover:text-primary transition-colors group">
                        <div className="p-2 rounded-lg group-hover:bg-primary/10 transition-colors">
                          <Share2 className="w-5 h-5" />
                        </div>
                        <span className="text-sm">Share</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Sidebar - Right */}
          <div className="space-y-6">
            {/* Trending Section */}
            <div className="card-post">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Trending
              </h3>
            </div>

            {/* Community Stats */}
            <div className="card-post">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Community
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Active Members</span>
                  <span className="font-semibold text-primary">0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Posts</span>
                  <span className="font-semibold text-accent">0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">New Members</span>
                  <span className="font-semibold text-primary">0</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Create Post Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-card rounded-xl max-w-2xl w-full shadow-2xl animate-slideUp">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 className="text-2xl font-bold text-foreground">
                Create Post
              </h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 hover:bg-secondary rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleCreatePost} className="p-6 space-y-6">
              {/* Author Info */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white font-bold text-lg">
                  🐾
                </div>
                <div>
                  <p className="font-semibold text-foreground">Your Account</p>
                </div>
              </div>

              {/* Title Input */}
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Title (Optional)
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  placeholder="Enter title"
                  className="w-full bg-secondary rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>

              {/* Content Input */}
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Content
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) =>
                    setFormData({ ...formData, content: e.target.value })
                  }
                  placeholder="What's on your mind?"
                  rows={6}
                  className="w-full bg-secondary rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                />
              </div>

              {/* Media Upload Hint */}
              <div className="bg-secondary/50 border-2 border-dashed border-border rounded-lg p-6 text-center">
                <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">
                  You can paste images and videos directly
                </p>
              </div>

              {/* Modal Actions */}
              <div className="flex gap-4 justify-end pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-6 py-2 rounded-lg font-semibold text-foreground hover:bg-secondary transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg font-semibold text-white bg-primary hover:bg-primary/90 transition-colors"
                >
                  Post
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
